# FabLab Lib Python

Generate necessary modules for FABLAB using Python Langquage

## Instructions

Install:

```
pip install fablablib-python-ver1
```
