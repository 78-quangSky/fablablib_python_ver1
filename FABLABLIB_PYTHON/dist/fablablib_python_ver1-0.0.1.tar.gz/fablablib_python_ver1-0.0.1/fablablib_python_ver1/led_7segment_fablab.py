class LEDSevenSegment:
    pass