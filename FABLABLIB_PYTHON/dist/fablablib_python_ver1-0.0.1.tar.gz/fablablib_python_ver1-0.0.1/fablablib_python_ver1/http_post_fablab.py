import requests


class HTTP:
    pass
#-------------Post http -----------------------------
# url_http="https://testthaiduongapi.azurewebsites.net/api/shiftreports/imm"
# url_http="https://thaiduongapi.azurewebsites.net/api/shiftreports/imm"
# headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
#----------------------------------------------------

#------------Post http------------
# x = requests.post(url_http, data=data_dict, headers=headers)
# print(x.status_code)
# print(x.text)
#---------------------------------