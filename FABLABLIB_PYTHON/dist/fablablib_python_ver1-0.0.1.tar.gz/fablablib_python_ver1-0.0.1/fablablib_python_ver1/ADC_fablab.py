class AnalogInput:
    pass