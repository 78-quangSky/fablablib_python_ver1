class DigitalOutput:
    pass