class AnalogOutput:
    pass