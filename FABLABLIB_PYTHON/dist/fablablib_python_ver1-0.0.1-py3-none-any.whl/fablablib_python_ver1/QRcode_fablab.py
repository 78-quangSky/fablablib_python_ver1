class QRcodeScan:
    pass