class LCD:
    pass