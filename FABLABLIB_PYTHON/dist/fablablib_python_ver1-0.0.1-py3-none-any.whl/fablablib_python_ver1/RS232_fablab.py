class RS232:
    pass