class DigitalInput:
    pass